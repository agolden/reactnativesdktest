## SalesforceMobileSDK-iOS-Dependencies

Binary dependencies for the Mobile SDK for iOS.

